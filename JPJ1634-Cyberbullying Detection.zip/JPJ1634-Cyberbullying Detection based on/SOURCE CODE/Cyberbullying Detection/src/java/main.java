import java.util.*;
class demo
{
    public static void main(string args[])
    {
        system.out.println("Welcome to java");
    }
}
