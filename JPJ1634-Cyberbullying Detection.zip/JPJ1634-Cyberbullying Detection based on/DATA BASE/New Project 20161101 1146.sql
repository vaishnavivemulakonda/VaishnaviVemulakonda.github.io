-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.0.22-community-nt


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema osn
--

CREATE DATABASE IF NOT EXISTS osn;
USE osn;

--
-- Definition of table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `word` varchar(45) NOT NULL,
  `bad` varchar(45) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` (`id`,`word`,`bad`) VALUES 
 (2,'BAD WORD','amateur'),
 (3,'BAD WORD','analphabet'),
 (4,'BAD WORD','anarchist'),
 (5,'BAD WORD','bastard'),
 (6,'BAD WORD','booby'),
 (7,'BAD WORD','boozer'),
 (8,'BAD WORD','bum'),
 (9,'BAD WORD','bum fucker'),
 (10,'BAD WORD','butt'),
 (11,'BAD WORD','cuttfucker'),
 (12,'BAD WORD','butthead'),
 (13,'BAD WORD','callboy'),
 (14,'BAD WORD','callgirl'),
 (15,'BAD WORD','children fucker'),
 (16,'BAD WORD','cockfucker'),
 (17,'BAD WORD','fuck face'),
 (18,'BAD WORD','fuck head'),
 (19,'BAD WORD','fucker'),
 (20,'BAD WORD','horse fucker'),
 (21,'BAD WORD','pervert'),
 (22,'BAD WORD','fuck'),
 (23,'BADWORD','perverted'),
 (24,'Illegal Words','Kill'),
 (26,'Bad Words','callboy'),
 (27,'Illegal Words','perverted');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;


--
-- Definition of table `chat`
--

DROP TABLE IF EXISTS `chat`;
CREATE TABLE `chat` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `send_name` varchar(45) NOT NULL,
  `reci_name` varchar(45) NOT NULL,
  `msg` varchar(45) NOT NULL,
  `date` varchar(45) NOT NULL,
  `photo` longblob NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chat`
--

/*!40000 ALTER TABLE `chat` DISABLE KEYS */;
/*!40000 ALTER TABLE `chat` ENABLE KEYS */;


--
-- Definition of table `cyber`
--

DROP TABLE IF EXISTS `cyber`;
CREATE TABLE `cyber` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `uid` varchar(45) NOT NULL,
  `name` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `gender` varchar(45) NOT NULL,
  `cybermessage` longtext NOT NULL,
  `cyber` varchar(45) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cyber`
--

/*!40000 ALTER TABLE `cyber` DISABLE KEYS */;
/*!40000 ALTER TABLE `cyber` ENABLE KEYS */;


--
-- Definition of table `reg`
--

DROP TABLE IF EXISTS `reg`;
CREATE TABLE `reg` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(45) NOT NULL,
  `sname` varchar(45) NOT NULL,
  `mail` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `dob` varchar(45) NOT NULL,
  `pass` varchar(45) NOT NULL,
  `gen` varchar(45) NOT NULL,
  `file_name` varchar(45) default NULL,
  `size` varchar(45) default NULL,
  `image` longblob,
  `sch` varchar(45) default NULL,
  `col` varchar(45) default NULL,
  `emp` varchar(45) default NULL,
  `allows` varchar(45) default NULL,
  `spam` int(11) default NULL,
  `cyber` varchar(45) default NULL,
  PRIMARY KEY  (`id`,`mail`,`email`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reg`
--

/*!40000 ALTER TABLE `reg` DISABLE KEYS */;
/*!40000 ALTER TABLE `reg` ENABLE KEYS */;


--
-- Definition of table `request`
--

DROP TABLE IF EXISTS `request`;
CREATE TABLE `request` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(45) NOT NULL,
  `fid` varchar(45) NOT NULL,
  `fname` varchar(45) NOT NULL,
  `status` varchar(45) NOT NULL,
  `relationship` varchar(45) NOT NULL,
  `fgroup` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `request`
--

/*!40000 ALTER TABLE `request` DISABLE KEYS */;
/*!40000 ALTER TABLE `request` ENABLE KEYS */;


--
-- Definition of table `timeline`
--

DROP TABLE IF EXISTS `timeline`;
CREATE TABLE `timeline` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `uid` varchar(45) NOT NULL,
  `name` varchar(45) NOT NULL,
  `msg` longtext NOT NULL,
  `photo` longblob NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `timeline`
--

/*!40000 ALTER TABLE `timeline` DISABLE KEYS */;
/*!40000 ALTER TABLE `timeline` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
